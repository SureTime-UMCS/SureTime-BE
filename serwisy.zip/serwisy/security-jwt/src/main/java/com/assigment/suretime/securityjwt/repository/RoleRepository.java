package com.assigment.suretime.securityjwt.repository;


import com.assigment.suretime.securityjwt.models.ERole;
import com.assigment.suretime.securityjwt.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role,Integer> {
  Optional<Role> findByName(ERole name);
}

package com.assigment.suretime.securityjwt.controller;

import com.assigment.suretime.securityjwt.models.Role;
import com.assigment.suretime.securityjwt.models.User;
import com.assigment.suretime.securityjwt.payload.request.LoginRequest;
import com.assigment.suretime.securityjwt.payload.request.SignupRequest;
import com.assigment.suretime.securityjwt.payload.response.JwtResponse;
import com.assigment.suretime.securityjwt.payload.response.MessageResponse;
import com.assigment.suretime.securityjwt.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashSet;
import java.util.Set;

@RestController
@RequestMapping("auth")
public class WelcomeController {

    @Autowired
    private AuthService authService;

    @GetMapping("/")
    public String welcome() {
        return "Welcome to javatechie !!";
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest authRequest){
        return authService.generateToken(authRequest);
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
       return authService.registerUser(signUpRequest);
    }
}

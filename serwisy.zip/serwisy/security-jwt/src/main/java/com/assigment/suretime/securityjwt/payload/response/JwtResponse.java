package com.assigment.suretime.securityjwt.payload.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
@Builder
public class JwtResponse {
	private String token;
	private int id;
	private String username;
	private String email;
	private List<String> roles;
}
package com.assigment.suretime.securityjwt;

import com.assigment.suretime.securityjwt.models.User;
import com.assigment.suretime.securityjwt.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
@EnableEurekaClient
public class SecurityJwtApplication {

	@Autowired
	private UserRepository repository;

	@Autowired
	PasswordEncoder encoder;

	@PostConstruct
	public void initUsers() {
		List<User> users = Stream.of(
				new User(102, "user1", encoder.encode("pwd1"), "user1@gmail.com", Collections.emptySet())
//				new User(103, "user2", "pwd2", "user2@gmail.com",Collections.emptySet()),
//				new User(104, "user3", "pwd3", "user3@gmail.com",Collections.emptySet())
		).collect(Collectors.toList());
		repository.saveAll(users);
	}

	public static void main(String[] args) {
		SpringApplication.run(SecurityJwtApplication.class, args);
	}

}

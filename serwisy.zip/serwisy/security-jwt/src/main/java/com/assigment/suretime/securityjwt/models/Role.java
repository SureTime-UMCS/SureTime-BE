package com.assigment.suretime.securityjwt.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Embeddable
@Table(name = "ROLES_TBL")
public class Role {

    @Id
    private int id;
    protected ERole name;

    public Role(ERole name) {
        this.name = name;
    }

}
